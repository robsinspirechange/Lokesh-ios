//
//  listarchitexture.swift
//  MY-ILP
//
//  Created by lokesh deshmukh on 20/07/1937 Saka.
//  Copyright (c) 1937 Saka TCS. All rights reserved.
//
import UIKit

class listarchitecture {
    // MARK: Properties
    
    var lecture: String
    var faculty: String
     var date: String
    var scheduleid=0;
    
    
    
    // MARK: Initialization
    
    init?(lecture: String,faculty: String,time: String, scheduleid: Int) {
        // Initialize stored properties.
        self.lecture = lecture
        self.faculty = faculty
        self.date = time
        self.scheduleid=scheduleid
        
        // Initialization should fail if there is no name or if the rating is negative.
        
    }
    
}