//
//  ListTableViewCell.swift
//  
//
//  Created by lokesh deshmukh on 20/07/1937 Saka.
//
//

import UIKit

class ListTableViewCell: UITableViewCell {

    @IBOutlet weak var lecture: UILabel!
    @IBOutlet weak var faculty: UILabel!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var image1: UIImageView!
    @IBOutlet weak var scheduleid: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
