//
//  ViewController.swift
//  Ascent-Apple
//
//  Created by lokesh deshmukh on 20/07/1937 Saka.
//  Copyright (c) 1937 Saka innovations. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var employeeid: UITextField!
    @IBOutlet weak var location: UIButton!
    @IBOutlet weak var emailid: UITextField!
    @IBOutlet weak var submit: UIButton!
    static var location="- select -";
    static var locationid="0";
    static var employeeid="";
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
       
        employeeid.layer.borderColor=(UIColor.whiteColor()).CGColor
        emailid.layer.borderColor=(UIColor.whiteColor()).CGColor
        name.layer.borderColor=(UIColor.whiteColor()).CGColor
        
        emailid.layer.borderWidth=1;
        employeeid.layer.borderWidth=1;
        name.layer.borderWidth=1;
        
        if true {
        let border = CALayer()
        let width = CGFloat(2.0)
        border.borderColor = UIColor.darkGrayColor().CGColor
        border.frame = CGRect(x: 0, y: employeeid.frame.size.height - width, width:  employeeid.frame.size.width, height: employeeid.frame.size.height)
        
        border.borderWidth = width
        employeeid.layer.addSublayer(border)
        employeeid.layer.masksToBounds = true
        
       
        }
        if true
        {
        let border = CALayer()
        let width = CGFloat(2.0)
        border.borderColor = UIColor.darkGrayColor().CGColor
        border.frame = CGRect(x: 0, y: emailid.frame.size.height - width, width:  emailid.frame.size.width, height: emailid.frame.size.height)
        
        border.borderWidth = width
        emailid.layer.addSublayer(border)
        emailid.layer.masksToBounds = true
     
        }
        if true
        {
        let border = CALayer()
        let width = CGFloat(2.0)
        border.borderColor = UIColor.darkGrayColor().CGColor
        border.frame = CGRect(x: 0, y: name.frame.size.height - width, width:  name.frame.size.width, height: name.frame.size.height)
        
        border.borderWidth = width
        name.layer.addSublayer(border)
        name.layer.masksToBounds = true
       
        }
        
        
        UIView.animateWithDuration(0.5, delay: 0,
            options: nil, animations: {
                self.employeeid.center.x += self.view.bounds.width
            }, completion: nil)
        UIView.animateWithDuration(0.5, delay: 0.1,
            options: nil, animations: {
                self.name.center.x += self.view.bounds.width
            }, completion: nil)
        UIView.animateWithDuration(0.5, delay: 0.2,
            options: nil, animations: {
                self.location.center.x += self.view.bounds.width
            }, completion: nil)
        UIView.animateWithDuration(0.5, delay: 0.3,
            options: nil, animations: {
                self.emailid.center.x += self.view.bounds.width
            }, completion: nil)
        
    }
    override func viewWillAppear(animated: Bool) {
        
        
        navigationItem.title = "Ascent"
        let defaults = NSUserDefaults.standardUserDefaults()
        defaults.classForCoder
        
        if let stringOne = defaults.valueForKey("EMP_ID") as? String {
            
            // Another String Value
            println(stringOne) // Some String Value
            
            
            ViewController.employeeid=(defaults.valueForKey("EMP_ID") as? String)!;
            ViewController.locationid=(defaults.valueForKey("EMP_LOCATION") as? String)!;
            
            
            
            dispatch_async(dispatch_get_main_queue(), {self.performSegueWithIdentifier("mainpage", sender: self)})
            //                    performSegueWithIdentifier("tomenu", sender: self)
            
        }
        location.setTitle(ViewController.location, forState: .Normal)
    }

  
    @IBAction func submit(sender: AnyObject) {
        if count(employeeid.text) < 1
        {
            let alertController = UIAlertController(title: "Message", message:
                "Enter Valid Employee Id", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        
        if count(name.text) < 1
        {
            let alertController = UIAlertController(title: "Message", message:
                "Enter Valid Name ", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        
        if location.titleLabel?.text != "Kochi" && location.titleLabel?.text != "Trivandrum"
        {
            let alertController = UIAlertController(title: "Message", message:
                "Select City ", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        
        if count(emailid.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())) > 8
        {
            if emailid.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet()).lowercaseString.rangeOfString("@tcs.com") != nil {
                
            }
            else
            {
                let alertController = UIAlertController(title: "Message", message:
                    "Enter Official Email Id", preferredStyle: UIAlertControllerStyle.Alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
                
                self.presentViewController(alertController, animated: true, completion: nil)
                return
            }
        }
        else
        {
            let alertController = UIAlertController(title: "Message", message:
                "Enter Valid Email Id", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        
        //--------------------------------loading code started
        var blurEffect = UIBlurEffect(style: UIBlurEffectStyle.Dark)
        var blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = view.bounds
        view.addSubview(blurEffectView)
        
        
        //screen shot and blur
        let snapShot = self.view.snapshotViewAfterScreenUpdates(false)
        view.addSubview(snapShot)
        UIView.animateWithDuration(0.25, animations: {
            snapShot.alpha = 0.0
            }, completion: { (finished: Bool) -> Void in
                snapShot.removeFromSuperview()
        } )
        //screen shot blur
        // Vibrancy Effect
        var vibrancyEffect = UIVibrancyEffect(forBlurEffect: blurEffect)
        var vibrancyEffectView = UIVisualEffectView(effect: vibrancyEffect)
        vibrancyEffectView.frame = view.bounds
        
        // Label for vibrant text
        var activityIndicator = UIActivityIndicatorView()
        activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.White)
        activityIndicator.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
        activityIndicator.startAnimating()
        activityIndicator.center = view.center
        
        // Add label to the vibrancy view
        vibrancyEffectView.contentView.addSubview(activityIndicator)
        
        // Add the vibrancy view to the blur view
        blurEffectView.contentView.addSubview(vibrancyEffectView)
        //------------------------------------------loading code end
        
       
        
        var uurl:String="http://theinspirer.in/ascent?action=register&empId="+employeeid.text+"&empName="+name.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet()).stringByReplacingOccurrencesOfString(" ", withString:"%20")+"&regionId="+ViewController.locationid.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet()).stringByReplacingOccurrencesOfString(" ", withString:"%20")+"&emailId="+emailid.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet()).stringByReplacingOccurrencesOfString(" ", withString:"%20");
        
        println(uurl)
        var endpoint = NSURL(string: uurl )
        var url = endpoint
        var request = NSURLRequest(URL: url!)// Creating Http Request
        
        // Creating NSOperationQueue to which the handler block is dispatched when the request completes or failed
        var queue: NSOperationQueue = NSOperationQueue()
        
        // Sending Asynchronous request using NSURLConnection
        NSURLConnection.sendAsynchronousRequest(request, queue: queue, completionHandler:{(response:NSURLResponse!, responseData:NSData!, error: NSError!) ->Void in
            
            if error != nil
            {
                println(error.description)
                dispatch_async(dispatch_get_main_queue()) {
                    blurEffectView.removeFromSuperview();
                    let alertController = UIAlertController(title: "Message", message:
                        "Network Error", preferredStyle: UIAlertControllerStyle.Alert)
                    alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
                    
                    self.presentViewController(alertController, animated: true, completion: nil)
                }
            }
            else
            {
                dispatch_async(dispatch_get_main_queue()) {
                    blurEffectView.removeFromSuperview();
                    //Converting data to String
                    var responseStr:NSString = NSString(data:responseData, encoding:NSUTF8StringEncoding)!
                    //  self.hiddenbutton.sendActionsForControlEvents(UIControlEvents.TouchUpInside)
                    // var err: NSError?
                    // var jsonResult = NSJSONSerialization.JSONObjectWithData(responseData, options: NSJSONReadingOptions.MutableContainers, error: &err) as! NSDictionary
                    
                    
                    
                    responseStr=responseStr.stringByReplacingOccurrencesOfString("\"", withString: "")
                    
                    println(responseStr)
                    
                    if responseStr.containsString("success:true")
                    {
                        let defaults = NSUserDefaults.standardUserDefaults()
                        
                        
                        
                        
                        
                        defaults.setValue(self.employeeid.text, forKey: "EMP_ID")
                        ViewController.employeeid=self.employeeid.text
                        defaults.setValue(ViewController.locationid, forKey: "EMP_LOCATION")
                        
                        
                        defaults.synchronize()
                        
                        self.performSegueWithIdentifier("mainpage", sender: self)
                    }
                    else
                    {
                        let alertController = UIAlertController(title: "Message", message:
                            "Invalid User" , preferredStyle: UIAlertControllerStyle.Alert)
                        alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
                        
                        self.presentViewController(alertController, animated: true, completion: nil)
                    }
                    
                    //  blurEffectView.removeFromSuperview();
                    
                    
                }
                
            }
        })
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

