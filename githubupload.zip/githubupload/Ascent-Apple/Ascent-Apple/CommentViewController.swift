//
//  CommentViewController.swift
//  
//
//  Created by lokesh deshmukh on 20/07/1937 Saka.
//
//

import UIKit

class CommentViewController: UIViewController {

    static var scheduleid=0;
    static var lecture="";
    static var faculty="";
    static var time="";
    @IBOutlet weak var comment: UITextView!
    @IBOutlet weak var lecture: UILabel!
    @IBOutlet weak var faculty: UILabel!
    @IBOutlet weak var time: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
    navigationItem.title = "Schedule"
        comment!.layer.borderWidth = 1
        comment!.layer.borderColor = UIColor.blueColor().CGColor
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
