//
//  SelectViewController.swift
//  
//
//  Created by lokesh deshmukh on 20/07/1937 Saka.
//
//

import UIKit

class SelectViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func kochi(sender: AnyObject) {
        ViewController.location="Kochi"
        ViewController.locationid="1"
        
        self.dismissViewControllerAnimated(true, completion: {});
    }

    @IBAction func trivandrum(sender: AnyObject) {
        ViewController.location="Trivandrum"
                ViewController.locationid="2"
        self.dismissViewControllerAnimated(true, completion: {});
    }
}
