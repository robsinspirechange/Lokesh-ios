//
//  MySlotViewController.swift
//  
//
//  Created by lokesh deshmukh on 19/07/1937 Saka.
//
//

import UIKit

class MySlotViewController: UIViewController {

    @IBOutlet weak var hours: UILabel!
    @IBOutlet weak var intime: UILabel!
    @IBOutlet weak var slot: UILabel!
    @IBOutlet weak var floor: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    override func viewWillAppear(animated: Bool) {
        
        navigationItem.title = "My Slot"
        
        //--------------------------------loading code started
        var blurEffect = UIBlurEffect(style: UIBlurEffectStyle.Dark)
        var blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = view.bounds
        view.addSubview(blurEffectView)
        
        
        //screen shot and blur
        let snapShot = self.view.snapshotViewAfterScreenUpdates(false)
        view.addSubview(snapShot)
        UIView.animateWithDuration(0.25, animations: {
            snapShot.alpha = 0.0
            }, completion: { (finished: Bool) -> Void in
                snapShot.removeFromSuperview()
        } )
        //screen shot blur
        // Vibrancy Effect
        var vibrancyEffect = UIVibrancyEffect(forBlurEffect: blurEffect)
        var vibrancyEffectView = UIVisualEffectView(effect: vibrancyEffect)
        vibrancyEffectView.frame = view.bounds
        
        // Label for vibrant text
        var activityIndicator = UIActivityIndicatorView()
        activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.White)
        activityIndicator.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
        activityIndicator.startAnimating()
        activityIndicator.center = view.center
        
        // Add label to the vibrancy view
        vibrancyEffectView.contentView.addSubview(activityIndicator)
        
        // Add the vibrancy view to the blur view
        blurEffectView.contentView.addSubview(vibrancyEffectView)
        //------------------------------------------loading code end
        
        var uurl:String="http://www.theinspirer.in/mlcpapp/?tag=GetBookingDetailsById&employeeId="+ViewController.employeeid;
        
        var endpoint = NSURL(string: uurl )
        var url = endpoint
        var request = NSURLRequest(URL: url!)// Creating Http Request
        
        // Creating NSOperationQueue to which the handler block is dispatched when the request completes or failed
        var queue: NSOperationQueue = NSOperationQueue()
        
        // Sending Asynchronous request using NSURLConnection
        NSURLConnection.sendAsynchronousRequest(request, queue: queue, completionHandler:{(response:NSURLResponse!, responseData:NSData!, error: NSError!) ->Void in
            
            if error != nil
            {
                println(error.description)
                dispatch_async(dispatch_get_main_queue()) {
                    blurEffectView.removeFromSuperview();
                    let alertController = UIAlertController(title: "Message", message:
                        "Network Error", preferredStyle: UIAlertControllerStyle.Alert)
                    alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
                    
                    self.presentViewController(alertController, animated: true, completion: nil)
                }
            }
            else
            {
                dispatch_async(dispatch_get_main_queue()) {
                    blurEffectView.removeFromSuperview();
                    //Converting data to String
                    var responseStr:NSString = NSString(data:responseData, encoding:NSUTF8StringEncoding)!
                    //  self.hiddenbutton.sendActionsForControlEvents(UIControlEvents.TouchUpInside)
                    // var err: NSError?
                    // var jsonResult = NSJSONSerialization.JSONObjectWithData(responseData, options: NSJSONReadingOptions.MutableContainers, error: &err) as! NSDictionary
                    
                    
                    
                    // responseStr=responseStr.stringByReplacingOccurrencesOfString("\"", withString: "")
                    
                    println(responseStr)
                    
                    if let json: NSDictionary = NSJSONSerialization.JSONObjectWithData(responseStr.dataUsingEncoding(NSUTF8StringEncoding)!, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary {
                        if let items = json["values"] as? NSArray {
                            for item in items {
                                
                                var temp: NSDictionary=item as! NSDictionary
                                for (key, value) in temp {
                                    if !(value is NSNull)
                                    {
                                        if(key as! String)=="floorname"
                                        {
                                            
                                            
                                            // self.AllSlots=value as? String;
                                            self.floor.text=value as? String;
                                            
                                        }
                                        
                                        if(key as! String)=="slotname"
                                        {
                                            
                                            
                                            // self.AllSlots=value as? String;
                                            self.slot.text=value as? String;
                                            
                                        }
                                        if(key as! String)=="book_timein"
                                        {
                                            
                                            
                                            // self.AllSlots=value as? String;
                                            self.intime.text=value as? String;
                                            
                                        }
                                        
                                        
                                        
                                    }
                                    
                                }
                            }
                        }
                    }
                    
                    
                    //println(item);
                    // construct your model objects here
                    
                    
                    
                    // Get #1 app name using SwiftyJSON
                    
                    
                    
                    //  blurEffectView.removeFromSuperview();
                    
                    
                }
                
            }
        })
        
    }


}
