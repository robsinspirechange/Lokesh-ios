//
//  SelectOptionsViewController.swift
//  
//
//  Created by lokesh deshmukh on 19/07/1937 Saka.
//
//

import UIKit

class SelectOptionsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
navigationItem.title = "Select Options"
        
       
        //self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.Bordered, target: nil, action: nil)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        
        
        self.navigationItem.hidesBackButton = false
        
 
        
        
        
        
        
    }
     override func viewWillAppear(animated: Bool) {
                //self.navigationItem.hidesBackButton = true
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
