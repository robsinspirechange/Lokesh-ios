//
//  selectlocation.swift
//  MLCP-Client
//
//  Created by lokesh deshmukh on 22/07/1937 SAKA.
//  Copyright (c) 1937 SAKA innovations. All rights reserved.
//

import UIKit

class selectlocation: UIViewController {

    @IBAction func kochi(sender: AnyObject) {
        ViewController.location="Kochi"
               self.dismissViewControllerAnimated(true, completion: {});
        
    }
    @IBOutlet weak var image1: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
            navigationItem.title = "Select City"
      /*  var darkBlur = UIBlurEffect(style: UIBlurEffectStyle.Dark)
        // 2
        var blurView = UIVisualEffectView(effect: darkBlur)
        blurView.frame = image1.bounds
        // 3
        image1.addSubview(blurView)
*/
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
