//
//  ViewController.swift
//  MLCP-Client
//
//  Created by lokesh deshmukh on 22/07/1937 SAKA.
//  Copyright (c) 1937 SAKA innovations. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var locationname: UIButton!
    @IBOutlet weak var empid: UITextField!
    static var location="- Select -";
    override func viewDidLoad() {
        super.viewDidLoad()
        
        email.delegate=self
        name.delegate=self
        empid.delegate=self
       
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    func back(sender: UIBarButtonItem) {
        // Perform your custom actions
        // ...
        // Go back to the previous ViewController
      //  self.navigationController?.popViewControllerAnimated(true)
    }
     static var employeeid="";
    @IBAction func submit(sender: AnyObject) {
        
       
        if count(empid.text) < 1
        {
            let alertController = UIAlertController(title: "Message", message:
                "Enter Valid Employee Id", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
        return
        }
        
        if count(name.text) < 1
        {
            let alertController = UIAlertController(title: "Message", message:
                "Enter Valid Name ", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        
        if locationname.titleLabel?.text != "Kochi"
        {
            let alertController = UIAlertController(title: "Message", message:
                "Select City ", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        
        if count(email.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())) > 8
        {
            if email.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet()).lowercaseString.rangeOfString("@tcs.com") != nil {
               
            }
            else
            {
                let alertController = UIAlertController(title: "Message", message:
                    "Enter Official Email Id", preferredStyle: UIAlertControllerStyle.Alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
                
                self.presentViewController(alertController, animated: true, completion: nil)
                return
            }
        }
        else
        {
            let alertController = UIAlertController(title: "Message", message:
                "Enter Valid Email Id", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        
        //--------------------------------loading code started
        var blurEffect = UIBlurEffect(style: UIBlurEffectStyle.Dark)
        var blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = view.bounds
        view.addSubview(blurEffectView)
        
        
        //screen shot and blur
        let snapShot = self.view.snapshotViewAfterScreenUpdates(false)
        view.addSubview(snapShot)
        UIView.animateWithDuration(0.25, animations: {
            snapShot.alpha = 0.0
            }, completion: { (finished: Bool) -> Void in
                snapShot.removeFromSuperview()
        } )
        //screen shot blur
        // Vibrancy Effect
        var vibrancyEffect = UIVibrancyEffect(forBlurEffect: blurEffect)
        var vibrancyEffectView = UIVisualEffectView(effect: vibrancyEffect)
        vibrancyEffectView.frame = view.bounds
        
        // Label for vibrant text
        var activityIndicator = UIActivityIndicatorView()
        activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.White)
        activityIndicator.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
        activityIndicator.startAnimating()
        activityIndicator.center = view.center
        
        // Add label to the vibrancy view
        vibrancyEffectView.contentView.addSubview(activityIndicator)
        
        // Add the vibrancy view to the blur view
        blurEffectView.contentView.addSubview(vibrancyEffectView)
        //------------------------------------------loading code end
        
        var uurl:String="http://theinspirer.in/mlcpapp/?tag=GetIsValidUser&employeeId="+empid.text+"&name="+name.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet()).stringByReplacingOccurrencesOfString(" ", withString:"%20");
        
        var endpoint = NSURL(string: uurl )
        var url = endpoint
        var request = NSURLRequest(URL: url!)// Creating Http Request
        
        // Creating NSOperationQueue to which the handler block is dispatched when the request completes or failed
        var queue: NSOperationQueue = NSOperationQueue()
        
        // Sending Asynchronous request using NSURLConnection
        NSURLConnection.sendAsynchronousRequest(request, queue: queue, completionHandler:{(response:NSURLResponse!, responseData:NSData!, error: NSError!) ->Void in
            
            if error != nil
            {
                println(error.description)
                dispatch_async(dispatch_get_main_queue()) {
                    blurEffectView.removeFromSuperview();
                    let alertController = UIAlertController(title: "Message", message:
                        "Network Error", preferredStyle: UIAlertControllerStyle.Alert)
                    alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
                    
                    self.presentViewController(alertController, animated: true, completion: nil)
                }
            }
            else
            {
                dispatch_async(dispatch_get_main_queue()) {
                    blurEffectView.removeFromSuperview();
                    //Converting data to String
                    var responseStr:NSString = NSString(data:responseData, encoding:NSUTF8StringEncoding)!
                    //  self.hiddenbutton.sendActionsForControlEvents(UIControlEvents.TouchUpInside)
                   // var err: NSError?
                   // var jsonResult = NSJSONSerialization.JSONObjectWithData(responseData, options: NSJSONReadingOptions.MutableContainers, error: &err) as! NSDictionary

                   
                    
                 responseStr=responseStr.stringByReplacingOccurrencesOfString("\"", withString: "")

                    println(responseStr)
                    
                    if responseStr.containsString("tag:GetIsValidUser,error:false,values:[]")
                    {
                        let defaults = NSUserDefaults.standardUserDefaults()
                        
                        
                        
                        
                        
                        defaults.setValue(self.empid.text, forKey: "EMP_ID")
                        ViewController.employeeid=self.empid.text
                        
                        defaults.synchronize()
                         
                          self.performSegueWithIdentifier("mainpage", sender: self)
                    }
                    else
                    {
                    let alertController = UIAlertController(title: "Message", message:
                        "Invalid User" , preferredStyle: UIAlertControllerStyle.Alert)
                    alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
                    
                    self.presentViewController(alertController, animated: true, completion: nil)
                    }
                    
                    //  blurEffectView.removeFromSuperview();
                    
                    
                }
                
            }
        })

        
        
    }
    
   override func viewWillAppear(animated: Bool) {
       navigationItem.title = "MLCP"
    let defaults = NSUserDefaults.standardUserDefaults()
    defaults.classForCoder
    
    if let stringOne = defaults.valueForKey("EMP_ID") as? String {
        
        // Another String Value
        println(stringOne) // Some String Value
        
        
        ViewController.employeeid=(defaults.valueForKey("EMP_ID") as? String)!;
        
        
        dispatch_async(dispatch_get_main_queue(), {self.performSegueWithIdentifier("mainpage", sender: self)})
        //                    performSegueWithIdentifier("tomenu", sender: self)
    }

    
    locationname.setTitle(ViewController.location, forState: .Normal)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(textField: UITextField!) -> Bool // called when 'return' key pressed. return NO to ignore.
    {
        textField.resignFirstResponder()
        return true;
    }


}

