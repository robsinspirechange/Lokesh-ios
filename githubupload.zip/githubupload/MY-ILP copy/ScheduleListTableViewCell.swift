//
//  ScheduleListTableViewCell.swift
//  MY-ILP
//
//  Created by lokesh deshmukh on 26/06/1937 SAKA.
//  Copyright (c) 1937 SAKA TCS. All rights reserved.
//

import UIKit

class ScheduleListTableViewCell: UITableViewCell {

  
  
    
    @IBOutlet weak var slot: UILabel!
   
    @IBOutlet weak var course: UILabel!
    @IBOutlet weak var faculty: UILabel!
    @IBOutlet weak var room: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
