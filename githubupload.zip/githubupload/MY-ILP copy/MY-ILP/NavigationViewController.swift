//
//  NavigationVewController.swift
//  NavTransition
//
//  Created by Tope Abayomi on 21/11/2014.
//  Copyright (c) 2014 App Design Vault. All rights reserved.


import Foundation
import Foundation
import UIKit

class NavigationViewController : UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var mainview: UIView!

    @IBOutlet var tableView   : UITableView!

    
    var items : [NavigationModel]!
    var snapshot : UIView = UIView()
    var transitionOperator = TransitionOperator()
    
    override func viewDidLoad() {
        super.viewDidLoad()
      //dimmerview.backgroundColor = UIColor(white: 0.0, alpha: 0.3)
      //  bgimageview.image = UIImage(named: "background.jpg")
        

    }
    
    @IBAction func myschedule(sender: AnyObject) {
        self.snapshot.removeFromSuperview()
        
        //view.addSubview(self.snapshot)
        performSegueWithIdentifier("schedule", sender: self)
    }
    @IBAction func mybadge(sender: AnyObject) {
        self.snapshot.removeFromSuperview()
        
        
        performSegueWithIdentifier("badge", sender: self)
    }
    @IBAction func emergencycontacts(sender: AnyObject) {
        self.snapshot.removeFromSuperview()
        
        
        performSegueWithIdentifier("emergency", sender: self)
    }
    @IBAction func notifications(sender: AnyObject) {
        //self.snapshot.removeFromSuperview()
        
        
        performSegueWithIdentifier("notification", sender: self)
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("NavigationCell") as! NavigationCell
        
        
        return cell
    }
    
    @IBAction func defaultclick(sender: AnyObject) {
        self.snapshot.removeFromSuperview()
        
        
        performSegueWithIdentifier("lokesh", sender: self)
        
    }
  func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        self.snapshot.removeFromSuperview()
        
       
            performSegueWithIdentifier("lokesh", sender: self)
            
        
    }
    
    func finalizeTransitionWithSnapshot(snapshot: UIView){
        self.snapshot = snapshot
        view.addSubview(self.snapshot)
    }
    
    override func preferredStatusBarStyle() -> UIStatusBarStyle {
        return .LightContent
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        TransitionOperator.snapshot1=self.view.snapshotViewAfterScreenUpdates(true)
        
        let toViewController = segue.destinationViewController as! UIViewController
        self.modalPresentationStyle = UIModalPresentationStyle.Custom
        toViewController.transitioningDelegate = self.transitionOperator
    }
    
       override func viewWillAppear(animated: Bool) {
        if   badgeTableViewController.errormsg==1
        {
            let alertController = UIAlertController(title: "Message", message:
                "Network Error", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
            badgeTableViewController.errormsg=0;
        }
        
        if ShowNotificationController.errormsg==1
        {
            let alertController = UIAlertController(title: "Message", message:
                "Network Error", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
            ShowNotificationController.errormsg=0;
        }
        
        if emergencyTableViewController.errormsg==1
        {
            let alertController = UIAlertController(title: "Message", message:
                "Network Error", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
            emergencyTableViewController.errormsg=0;
        }
    }
    
    @IBOutlet weak var bgimageview: UIImageView!
    @IBOutlet weak var dimmerview: UIView!
    
    @IBAction func goback(sender: AnyObject) {
      self.dismissViewControllerAnimated(true, completion: {});
    }
}

class NavigationModel {
    
    var title : String!
    var icon : String!
    var count : String?
    
    init(title: String, icon : String){
        self.title = title
        self.icon = icon
    }
    
    init(title: String, icon : String, count: String){
        self.title = title
        self.icon = icon
        self.count = count
    }
}
