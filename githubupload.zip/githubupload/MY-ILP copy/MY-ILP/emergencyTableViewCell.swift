//
//  emergencyTableViewCell.swift
//  MY-ILP
//
//  Created by lokesh deshmukh on 27/06/1937 SAKA.
//  Copyright (c) 1937 SAKA TCS. All rights reserved.
//

import UIKit

class emergencyTableViewCell: UITableViewCell {

    @IBOutlet weak var number: UILabel!
    @IBOutlet weak var title: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
