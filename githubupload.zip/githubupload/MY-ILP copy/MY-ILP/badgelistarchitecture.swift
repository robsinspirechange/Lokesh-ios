//
//  badgelistarchitecture.swift
//  MY-ILP
//
//  Created by lokesh deshmukh on 27/06/1937 SAKA.
//  Copyright (c) 1937 SAKA TCS. All rights reserved.
//

import UIKit

class badgelistarchitecture {
    // MARK: Properties
    
    var name: String
    var points: String
    
    
    
    
    
    // MARK: Initialization
    
    init?(name: String,points: String) {
        // Initialize stored properties.
        self.name = name
        self.points = points

        
        // Initialization should fail if there is no name or if the rating is negative.
        
    }
    
}