//
//  badgeTableViewCell.swift
//  MY-ILP
//
//  Created by lokesh deshmukh on 27/06/1937 SAKA.
//  Copyright (c) 1937 SAKA TCS. All rights reserved.
//

import UIKit

class badgeTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet weak var points: UILabel!
    @IBOutlet weak var name: UILabel!
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
