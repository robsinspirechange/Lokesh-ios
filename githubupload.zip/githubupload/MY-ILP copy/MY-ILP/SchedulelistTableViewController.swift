//
//  SchedulelistTableViewController.swift
//  MY-ILP
//
//  Created by lokesh deshmukh on 26/06/1937 SAKA.
//  Copyright (c) 1937 SAKA TCS. All rights reserved.
//

import UIKit
import Foundation

class SchedulelistTableViewController: UITableViewController {
    
   
  static var data1:NSData!
    static var url:NSURL!
    var ScheduleArchitecturevar = [ScheduleArchitecture]()
   
    
    @IBAction func back(sender: AnyObject) {
              self.dismissViewControllerAnimated(true, completion: {});
   
       
    
    }
    var bit=0;
    override func viewDidLoad() {
        super.viewDidLoad()
        if UIScreen.mainScreen().bounds.size.height>768
        {
            uitable?.rowHeight=100;
        }
        
          //uitable.allowsSelection = false;
        //database connectioncode
        
        let filemgr = NSFileManager.defaultManager()
        let dirPaths =
        NSSearchPathForDirectoriesInDomains(.DocumentDirectory,
            .UserDomainMask, true)
        
        let docsDir = dirPaths[0] as! String
        
        databasePath = docsDir.stringByAppendingPathComponent(
            "contacts.db")
        
        if !filemgr.fileExistsAtPath(databasePath as String) {
            
            let contactDB = FMDatabase(path: databasePath as String)
            
            if contactDB == nil {
                println("Error: \(contactDB.lastErrorMessage())")
            }
            
            if contactDB.open() {
                let sql_stmt = "CREATE TABLE IF NOT EXISTS MY_ILP_SCHEDULE1 (SNO INTEGER PRIMARY KEY AUTOINCREMENT, slot TEXT, course TEXT,faculty TEXT,room TEXT,date TEXT,batch TEXT)"
                if !contactDB.executeStatements(sql_stmt) {
                    println("Error: \(contactDB.lastErrorMessage())")
                }
                contactDB.close()
            } else {
                println("Error: \(contactDB.lastErrorMessage())")
            }
        }

        
        //database connectioncode

        
     // self.uitable.backgroundColor = UIColor(patternImage: UIImage(named: "background.jpg")!)
        loadSampleMeals()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    static var date1:String?=""
    static var errormsg=0;
    func loadSampleMeals() {

       // delete()
        if (selectquery() as Int) > 0 || (selectquery() as Int) == 100
        {

            fillwithlocaldatabase(GetbatchandtimeViewController.course)
            return
        }
        
        
        //--------------------------------loading code started
        var blurEffect = UIBlurEffect(style: UIBlurEffectStyle.Dark)
        var blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = view.bounds
        view.addSubview(blurEffectView)
        
        
        //screen shot and blur
        let snapShot = self.view.snapshotViewAfterScreenUpdates(false)
        view.addSubview(snapShot)
        UIView.animateWithDuration(0.25, animations: {
            snapShot.alpha = 0.0
            }, completion: { (finished: Bool) -> Void in
                snapShot.removeFromSuperview()
        } )
        //screen shot blur
        // Vibrancy Effect
        var vibrancyEffect = UIVibrancyEffect(forBlurEffect: blurEffect)
        var vibrancyEffectView = UIVisualEffectView(effect: vibrancyEffect)
        vibrancyEffectView.frame = view.bounds
        
        // Label for vibrant text
        var activityIndicator = UIActivityIndicatorView()
        activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.White)
        activityIndicator.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
        activityIndicator.startAnimating()
        activityIndicator.center = view.center
        
        // Add label to the vibrancy view
        vibrancyEffectView.contentView.addSubview(activityIndicator)
        
        // Add the vibrancy view to the blur view
        blurEffectView.contentView.addSubview(vibrancyEffectView)
        //------------------------------------------loading code end
        
        SchedulelistTableViewController.errormsg=0;
        var url = SchedulelistTableViewController.url
        var request = NSURLRequest(URL: url!)// Creating Http Request
        
        // Creating NSOperationQueue to which the handler block is dispatched when the request completes or failed
        var queue: NSOperationQueue = NSOperationQueue()
        
        // Sending Asynchronous request using NSURLConnection
        NSURLConnection.sendAsynchronousRequest(request, queue: queue, completionHandler:{(response:NSURLResponse!, responseData:NSData!, error: NSError!) ->Void in
            
            if error != nil
            {
                 //blurEffectView.removeFromSuperview();
                println(error.description)
                
                dispatch_async(dispatch_get_main_queue()) {
                    //blurEffectView.removeFromSuperview();
                    SchedulelistTableViewController.errormsg=1;
                        self.dismissViewControllerAnimated(true, completion: nil);
                }
                
            }
            else
            {
                dispatch_async(dispatch_get_main_queue()) {
                    
                    blurEffectView.removeFromSuperview();
                    //Converting data to String
                    var responseStr:NSString = NSString(data:responseData, encoding:NSUTF8StringEncoding)!
                   var data1=responseStr.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                    //  blurEffectView.removeFromSuperview();

                    if let json: NSDictionary = NSJSONSerialization.JSONObjectWithData(data1!, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary {
                        if let items = json["Android"] as? NSArray {
                            
                            for item in items {
                                
                                
                                
                                
                                let photo4 = UIImage(named: "ContactsIcon.png")!
                                
                                var slot:String=""
                                var course:String=""
                                var faculty:String=""
                                var room:String=""
                                
                                
                                var temp: NSDictionary=item as! NSDictionary
                                for (key, value) in temp {
                                    if !(value is NSNull)
                                    {
                                        if(key as! String)=="slot"
                                        {
                                            slot=value as! String
                                        }
                                        if(key as! String)=="course"
                                        {
                                            course=value as! String
                                        }
                                        if(key as! String)=="faculty"
                                        {
                                            faculty=value as! String
                                        }
                                        if(key as! String)=="room"
                                        {
                                            room=value as! String
                                        }
                                    }
                                    
                                    
                                }
                                self.insertquery(slot as String, course: course as String, faculty: faculty as String, room: room as String, date: SchedulelistTableViewController.date1! as String)
                                //    let   ScheduleArchitecture4 = ScheduleArchitecture(slot: slot as String,course : course,faculty:faculty,room:room)!
                                //   ScheduleArchitecturevar += [ScheduleArchitecture4]
                                
                                //println(loki);
                                // construct your model objects here
                            }
                            
                        }
                       self.fillwithlocaldatabase(GetbatchandtimeViewController.course)
                        
                        
                    }


                }
            }
        })

        
               //network load
        
        
        //network load
        
      
        
      
        
    }
   var loki:String=""
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }
   
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        
        
        return ScheduleArchitecturevar.count
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        
        let cellIdentifier = "ScheduleListTableViewCell"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as! ScheduleListTableViewCell
        
        // Fetches the appropriate meal for the data source layout.
        let obj = ScheduleArchitecturevar[indexPath.row]
        
        cell.slot.text = obj.slot
        cell.faculty.text=obj.faculty
       
        
        cell.course.text=obj.course
        cell.room.text=obj.room
       // cell.course.text = obj.
        
        //network loader
        /*  ImageLoader.sharedLoader.imageForUrl("http://cdn2.raywenderlich.com/wp-content/themes/raywenderlich/images/store/profile-page-products/i6t@2x.png", completionHandler:{(image: UIImage?, url: String) in
        cell.image1.image = image!
        })*/
        //network loader
        
        
cell.selectionStyle = UITableViewCellSelectionStyle.None
        
        return cell
        
    
    }
    func getDataFromUrl(urL:NSURL, completion: ((data: NSData?) -> Void)) {
        NSURLSession.sharedSession().dataTaskWithURL(urL) { (data, response, error) in
            completion(data: data)
            }.resume()
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        //CODE TO BE RUN ON CELL TOUCH
        println(indexPath.item);
        
        //   let vc = storyboard!.instantiateViewControllerWithIdentifier("Schedule") as! UIViewController
        // self.presentViewController(vc, animated: true, completion: nil)
        
        
    }
    @IBOutlet var uitable: UITableView!
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        
        
        
        let indexPath = self.uitable!.indexPathForSelectedRow()!
        let strImageName = ScheduleArchitecturevar[indexPath.row]
        feedbackViewController.name = strImageName.faculty
        feedbackViewController.course = strImageName.course
        feedbackViewController.slot=strImageName.slot
        
        
  
        
        
    }
    override func viewWillAppear(animated: Bool) {
        navigationItem.title = "Schedule"
        
       /* if feedbackViewController.errormsg == 1
        {
            feedbackViewController.errormsg=0
            let alertController = UIAlertController(title: "Message", message:
                "Posted Sucessfully", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
        }
        if feedbackViewController.errormsg == 2
        {
            feedbackViewController.errormsg=0
            let alertController = UIAlertController(title: "Message", message:
                "Cannot Give Feedback For Future Dates", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
        }
        */
        
    }
    
    func delete()->Int
    {
        let contactDB = FMDatabase(path: databasePath as String)
        
        if contactDB.open() {
            let querySQL = "delete from  MY_ILP_SCHEDULE1 "
            
            let results:FMResultSet? = contactDB.executeQuery(querySQL,
                withArgumentsInArray: nil)
            
            if results?.next() == true {
                //  var ret = results?.stringForColumn("lines").toInt()
                println("Record Found")
                // println(ret)
                //return ret!;
                
            } else {
                println("Record Not Found")
                
            }
            contactDB.close()
            
        } else {
            println("Error: \(contactDB.lastErrorMessage())")
        }
        return 100
    }
    
    
    func insertquery(slot:String,course:String,faculty:String,room:String,date:String){
        let contactDB = FMDatabase(path: databasePath as String)
        
        if contactDB.open() {
            
            let insertSQL = "INSERT INTO MY_ILP_SCHEDULE1 (slot,course,faculty,room,date,batch) VALUES ('\(slot)','\(course)','\(faculty)','\(room)','\(date)','\(GetbatchandtimeViewController.course)')"
            
            let result = contactDB.executeUpdate(insertSQL,
                withArgumentsInArray: nil)
            
            if !result {
                println("Failed to add contact")
                println("Error: \(contactDB.lastErrorMessage())")
            } else {
                println("Contact added")
                println(course)
            }
        } else {
            println("Error: \(contactDB.lastErrorMessage())")
        }
    }
    
    func selectquery()->Int
    {
        let contactDB = FMDatabase(path: databasePath as String)
        
        if contactDB.open() {
            let querySQL = "SELECT count(*) as lines FROM MY_ILP_SCHEDULE1 where date='"+SchedulelistTableViewController.date1!+"' and batch='"+GetbatchandtimeViewController.course+"'"
            
            let results:FMResultSet? = contactDB.executeQuery(querySQL,
                withArgumentsInArray: nil)
            
            if results?.next() == true {
                var ret = results?.stringForColumn("lines").toInt()
                println("Record Found")
                println(ret)
                contactDB.close()
                return ret!;
                
            } else {
                println("Record Not Found")
                
            }
            contactDB.close()
            
        } else {
            println("Error: \(contactDB.lastErrorMessage())")
        }
        return 100
    }
     var databasePath:String=""
    func fillwithlocaldatabase(course:String)
    {
        dispatch_async(dispatch_get_main_queue()) {
        let contactDB = FMDatabase(path: self.databasePath as String)
        
        if contactDB.open() {
            let querySQL = "SELECT * FROM MY_ILP_SCHEDULE1 where date='"+SchedulelistTableViewController.date1!+"' and batch='"+course+"'"
            
            let results:FMResultSet? = contactDB.executeQuery(querySQL,
                withArgumentsInArray: nil)
            
            while results?.next() == true {
                var slot=results?.stringForColumn("slot")
                var course=results?.stringForColumn("course")
                var faculty=results?.stringForColumn("faculty")
                var room=results?.stringForColumn("room")
                println("Record Found")
                let   ScheduleArchitecture4 = ScheduleArchitecture(slot: slot!,course : course!,faculty:faculty!,room:room!)!
                self.ScheduleArchitecturevar += [ScheduleArchitecture4]
                self.tableView.reloadData()
            }
            contactDB.close()
        
            
            
        } else {
            println("Error: \(contactDB.lastErrorMessage())")
        }
        }
    }
    
   
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
    // Return NO if you do not want the specified item to be editable.
    return true
    }
    */
    
    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
    if editingStyle == .Delete {
    // Delete the row from the data source
    tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
    } else if editingStyle == .Insert {
    // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }
    }
    */
    
    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
    
    }
    */
    
    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
    // Return NO if you do not want the item to be re-orderable.
    return true
    }
    */
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    }
    */
    
}
class ImageLoader {
    
    var cache = NSCache()
    
    class var sharedLoader : ImageLoader {
        struct Static {
            static let instance : ImageLoader = ImageLoader()
        }
        return Static.instance
    }
    
    func imageForUrl(urlString: String, completionHandler:(image: UIImage?, url: String) -> ()) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), {()in
            var data: NSData? = self.cache.objectForKey(urlString) as? NSData
            
            if let goodData = data {
                let image = UIImage(data: goodData)
                dispatch_async(dispatch_get_main_queue(), {() in
                    completionHandler(image: image, url: urlString)
                })
                return
            }
            
            var downloadTask: NSURLSessionDataTask = NSURLSession.sharedSession().dataTaskWithURL(NSURL(string: urlString)!, completionHandler: {(data: NSData!, response: NSURLResponse!, error: NSError!) -> Void in
                if (error != nil) {
                    completionHandler(image: nil, url: urlString)
                    return
                }
                
                if data != nil {
                    let image = UIImage(data: data)
                    self.cache.setObject(data, forKey: urlString)
                    dispatch_async(dispatch_get_main_queue(), {() in
                        completionHandler(image: image, url: urlString)
                    })
                    return
                }
                
            })
            downloadTask.resume()
        })
        
    }

}
