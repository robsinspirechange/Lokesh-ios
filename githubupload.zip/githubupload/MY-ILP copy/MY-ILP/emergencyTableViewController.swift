//
//  emergencyTableViewController.swift
//  MY-ILP
//
//  Created by lokesh deshmukh on 27/06/1937 SAKA.
//  Copyright (c) 1937 SAKA TCS. All rights reserved.
//

import UIKit

class emergencyTableViewController: UITableViewController {
    
    
    @IBAction func goback(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: {});
    }
    
    
    var databasePath:String=""
    @IBOutlet var uitable: UITableView!
    var emergencyarchitecturevar = [emergencyarchitecture]()
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        
        
        //database code
        
        let filemgr = NSFileManager.defaultManager()
        let dirPaths =
        NSSearchPathForDirectoriesInDomains(.DocumentDirectory,
            .UserDomainMask, true)
        
        let docsDir = dirPaths[0] as! String
        
        databasePath = docsDir.stringByAppendingPathComponent(
            "contacts1.db")
        
        if !filemgr.fileExistsAtPath(databasePath as String) {
            
            let contactDB = FMDatabase(path: databasePath as String)
            
            if contactDB == nil {
                println("Error: \(contactDB.lastErrorMessage())")
            }
            
            if contactDB.open() {
                let sql_stmt = "CREATE TABLE IF NOT EXISTS MY_ILP_EMERGENCY_CONTACTS (SNO INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, PHONE TEXT)"
                if !contactDB.executeStatements(sql_stmt) {
                    println("Error: \(contactDB.lastErrorMessage())")
                }
                contactDB.close()
            } else {
                println("Error: \(contactDB.lastErrorMessage())")
            }
        }
        
        
        //database code
        loadSampleMeals()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    var number = [String]()
    static var errormsg=0;
    func loadSampleMeals() {
        
        //--------------------------------loading code started
        var blurEffect = UIBlurEffect(style: UIBlurEffectStyle.Dark)
        var blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = view.bounds
        view.addSubview(blurEffectView)
        
        
        //screen shot and blur
        let snapShot = self.view.snapshotViewAfterScreenUpdates(false)
        view.addSubview(snapShot)
        UIView.animateWithDuration(1.25, animations: {
            snapShot.alpha = 0.0
            }, completion: { (finished: Bool) -> Void in
                snapShot.removeFromSuperview()
        } )
        //screen shot blur
        // Vibrancy Effect
        var vibrancyEffect = UIVibrancyEffect(forBlurEffect: blurEffect)
        var vibrancyEffectView = UIVisualEffectView(effect: vibrancyEffect)
        vibrancyEffectView.frame = view.bounds
        
        // Label for vibrant text
        var activityIndicator = UIActivityIndicatorView()
        activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.White)
        activityIndicator.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
        activityIndicator.startAnimating()
        activityIndicator.center = view.center
        
        // Add label to the vibrancy view
        vibrancyEffectView.contentView.addSubview(activityIndicator)
        
        // Add the vibrancy view to the blur view
        blurEffectView.contentView.addSubview(vibrancyEffectView)
        //------------------------------------------loading code end
        
       // delete()
        //check exist in database
       if ( self.selectquery() as Int) != 100 && (self.selectquery() as Int) != 0
       {
        fillwithlocaldatabase();
        blurEffectView.removeFromSuperview();
        
    
      //  self.uitable.backgroundView=nil
        //self.uitable.backgroundColor = UIColor(patternImage: UIImage(named: "background.jpg")!)
       // var colors=Colors()
        
       // view.backgroundColor = UIColor.clearColor()
       // var backgroundLayer = colors.gl
       // backgroundLayer.frame = view.frame
       // view.layer.insertSublayer(backgroundLayer, atIndex: 0)
        return;
        }
        //check exist in database
        
        emergencyTableViewController.errormsg=0;
        var endpoint = NSURL(string: "http://theinspirer.in/ilpscheduleapp/getEmergencyContacts.php?ilp=Trivandrum")
        var url = endpoint
        var request = NSURLRequest(URL: url!)// Creating Http Request
        
        // Creating NSOperationQueue to which the handler block is dispatched when the request completes or failed
        var queue: NSOperationQueue = NSOperationQueue()
        
        // Sending Asynchronous request using NSURLConnection
        NSURLConnection.sendAsynchronousRequest(request, queue: queue, completionHandler:{(response:NSURLResponse!, responseData:NSData!, error: NSError!) ->Void in
            
            if error != nil
            {
                println(error.description)
                dispatch_async(dispatch_get_main_queue()) {
                           emergencyTableViewController.errormsg=1;
                    self.dismissViewControllerAnimated(false, completion: nil);
                }
            }
            else
            {
                dispatch_async(dispatch_get_main_queue()) {
                var data1:NSData!
                //Converting data to String
                var responseStr:NSString = NSString(data:responseData, encoding:NSUTF8StringEncoding)!
//                data1=responseStr.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
            
                self.view.backgroundColor = UIColor.whiteColor()
                
                var fullNameArr = split(responseStr as String) {$0 == ","}
                
                for var i=0;i<fullNameArr.count;i++
                {
                var firstName=split(fullNameArr[i] as String) {$0 == ":"}
                  
                    var title:String=firstName[0].stringByReplacingOccurrencesOfString("\"", withString: "").stringByReplacingOccurrencesOfString("{", withString: "").stringByReplacingOccurrencesOfString("[", withString: "").stringByReplacingOccurrencesOfString("]", withString: "").stringByReplacingOccurrencesOfString("}", withString: "")
                    var number:String=firstName[1].stringByReplacingOccurrencesOfString("\"", withString: "").stringByReplacingOccurrencesOfString("{", withString: "").stringByReplacingOccurrencesOfString("[", withString: "").stringByReplacingOccurrencesOfString("]", withString: "").stringByReplacingOccurrencesOfString("}", withString: "")
                    
                    
                    self.insertquery(title as String,phone: number as String)
                   //println(self.selectquery());
                    
                  //  let   ScheduleArchitecture4 = emergencyarchitecture(title: title as String,number :number)!
                  //  self.emergencyarchitecturevar += [ScheduleArchitecture4]
                    }
                        blurEffectView.removeFromSuperview();
                    self.fillwithlocaldatabase();
                            //println(item);
                            // construct your model objects here
                    
                
                self.uitable.reloadData()
                
                }
            }
        })
        
        
        
        //network load
        
        
        //network load
        
        
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete method implementation.
        // Return the number of rows in the section.
        
        
        
        return emergencyarchitecturevar.count
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cellIdentifier = "emergencyTableViewCell"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as! emergencyTableViewCell
        
        // Fetches the appropriate meal for the data source layout.
        let obj = emergencyarchitecturevar[indexPath.row]
        
        cell.title.text = obj.title
        cell.number.text=obj.number
        number.append(obj.number!)
        // cell.course.text = obj.
        
        //network loader
        /*  ImageLoader.sharedLoader.imageForUrl("http://cdn2.raywenderlich.com/wp-content/themes/raywenderlich/images/store/profile-page-products/i6t@2x.png", completionHandler:{(image: UIImage?, url: String) in
        cell.image1.image = image!
        })*/
        //network loader
       /* if (indexPath.row % 2 == 0)
        {
            cell.backgroundColor = UIColor.grayColor()
        }
        else
        {
            cell.backgroundColor = UIColor.whiteColor()
        }
        */
//        cell.backgroundView=nil;
  //      cell.backgroundColor=nil;
        return cell
    }
    
    class Colors {
        let colorTop = UIColor(red: 0, green: 0, blue: 1.0, alpha: 1.0).CGColor
        let colorBottom = UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0).CGColor
        
        let gl: CAGradientLayer
        
        init() {
            gl = CAGradientLayer()
            gl.colors = [ colorTop, colorBottom]
            gl.locations = [ 0.0, 2.0]
        }
    }
    
    func getDataFromUrl(urL:NSURL, completion: ((data: NSData?) -> Void)) {
        NSURLSession.sharedSession().dataTaskWithURL(urL) { (data, response, error) in
            completion(data: data)
            }.resume()
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        //CODE TO BE RUN ON CELL TOUCH
        println(indexPath.item);
        
        
        
        
        let phone = "tel://"+number[indexPath.item];
        let url:NSURL = NSURL(string:phone)!;
        UIApplication.sharedApplication().openURL(url);
        //   let vc = storyboard!.instantiateViewControllerWithIdentifier("Schedule") as! UIViewController
        // self.presentViewController(vc, animated: true, completion: nil)
        
        
    }
    
    

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        let indexPath = self.uitable!.indexPathForSelectedRow()!
        let strImageName = emergencyarchitecturevar[indexPath.row]
        
        
        let phone = "tel://"+strImageName.number!;
        let url:NSURL = NSURL(string:phone)!;
        UIApplication.sharedApplication().openURL(url);
        
        
        
    }
    override func viewWillAppear(animated: Bool) {
        navigationItem.title = "Emergency Contacts"
       
        
    }
    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
    // Return NO if you do not want the specified item to be editable.
    return true
    }
    */
    
    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
    if editingStyle == .Delete {
    // Delete the row from the data source
    tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
    } else if editingStyle == .Insert {
    // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }
    }
    */
    
    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
    
    }
    */
    
    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
    // Return NO if you do not want the item to be re-orderable.
    return true
    }
    */
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    }
    */
    
    func delete()->Int
    {
        let contactDB = FMDatabase(path: databasePath as String)
        
        if contactDB.open() {
            let querySQL = "delete from  MY_ILP_EMERGENCY_CONTACTS "
            
            let results:FMResultSet? = contactDB.executeQuery(querySQL,
                withArgumentsInArray: nil)
            
            if results?.next() == true {
              //  var ret = results?.stringForColumn("lines").toInt()
                println("Record Found")
               // println(ret)
                //return ret!;
                
            } else {
                println("Record Not Found")
                
            }
            contactDB.close()
            
        } else {
            println("Error: \(contactDB.lastErrorMessage())")
        }
        return 100
    }
    func insertquery(name:String,phone:String){
        let contactDB = FMDatabase(path: databasePath as String)
        
        if contactDB.open() {
            
            let insertSQL = "INSERT INTO MY_ILP_EMERGENCY_CONTACTS (name, phone) VALUES ('\(name)','\(phone)')"
            
            let result = contactDB.executeUpdate(insertSQL,
                withArgumentsInArray: nil)
            
            if !result {
                println("Failed to add contact")
                println("Error: \(contactDB.lastErrorMessage())")
            } else {
                 println("Contact added")
            }
        } else {
            println("Error: \(contactDB.lastErrorMessage())")
        }
    }
    
    func selectquery()->Int
    {
        let contactDB = FMDatabase(path: databasePath as String)
        
        if contactDB.open() {
            let querySQL = "SELECT count(*) as lines FROM MY_ILP_EMERGENCY_CONTACTS "
            
            let results:FMResultSet? = contactDB.executeQuery(querySQL,
                withArgumentsInArray: nil)
            
            if results?.next() == true {
                var ret = results?.stringForColumn("lines").toInt()
                 println("Record Found")
                println(ret)
                return ret!;
               
            } else {
                println("Record Not Found")
                
            }
            contactDB.close()
            
        } else {
            println("Error: \(contactDB.lastErrorMessage())")
        }
        return 100
    }
    
    func fillwithlocaldatabase()
    {
        let contactDB = FMDatabase(path: databasePath as String)
        
        if contactDB.open() {
            let querySQL = "SELECT * FROM MY_ILP_EMERGENCY_CONTACTS "
            
            let results:FMResultSet? = contactDB.executeQuery(querySQL,
                withArgumentsInArray: nil)
            
            while results?.next() == true {
                var name=results?.stringForColumn("NAME")
                var phone=results?.stringForColumn("PHONE")
                println("Record Found")
        let   ScheduleArchitecture4 = emergencyarchitecture(title: name! ,number : phone!)!
        self.emergencyarchitecturevar += [ScheduleArchitecture4]
                
            }
            contactDB.close()
            
        } else {
            println("Error: \(contactDB.lastErrorMessage())")
        }
     
    }
    
    class ImageLoader {
        
        var cache = NSCache()
        
        class var sharedLoader : ImageLoader {
            struct Static {
                static let instance : ImageLoader = ImageLoader()
            }
            return Static.instance
        }
        
        func imageForUrl(urlString: String, completionHandler:(image: UIImage?, url: String) -> ()) {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), {()in
                var data: NSData? = self.cache.objectForKey(urlString) as? NSData
                
                if let goodData = data {
                    let image = UIImage(data: goodData)
                    dispatch_async(dispatch_get_main_queue(), {() in
                        completionHandler(image: image, url: urlString)
                    })
                    return
                }
                
                var downloadTask: NSURLSessionDataTask = NSURLSession.sharedSession().dataTaskWithURL(NSURL(string: urlString)!, completionHandler: {(data: NSData!, response: NSURLResponse!, error: NSError!) -> Void in
                    if (error != nil) {
                        completionHandler(image: nil, url: urlString)
                        return
                    }
                    
                    if data != nil {
                        let image = UIImage(data: data)
                        self.cache.setObject(data, forKey: urlString)
                        dispatch_async(dispatch_get_main_queue(), {() in
                            completionHandler(image: image, url: urlString)
                        })
                        return
                    }
                    
                })
                downloadTask.resume()
            })
            
        }
        
    }

}
