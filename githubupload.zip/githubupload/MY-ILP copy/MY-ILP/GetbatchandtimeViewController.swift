//
//  GetbatchandtimeViewController.swift
//  MY-ILP
//
//  Created by lokesh deshmukh on 26/06/1937 SAKA.
//  Copyright (c) 1937 SAKA TCS. All rights reserved.
//

import UIKit

class GetbatchandtimeViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var batch: UITextField!
   
    @IBOutlet weak var date: UIDatePicker!
    override func viewDidLoad() {
        super.viewDidLoad()
batch.delegate=self
        // Do any additional setup after loading the view.
    }
override func viewDidAppear(animated: Bool)
{
    self.view.backgroundColor=UIColor.whiteColor()
    if count(batch.text)<1
    {
    batch.text=ViewController.emp_lg;
    }
    if SchedulelistTableViewController.errormsg==1
    {
        let alertController = UIAlertController(title: "Message", message:
            "Network Error", preferredStyle: UIAlertControllerStyle.Alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
        
        self.presentViewController(alertController, animated: true, completion: nil)
    }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func getschedule(sender: AnyObject) {
        var dateFormatter = NSDateFormatter()
        
        dateFormatter.dateStyle = NSDateFormatterStyle.ShortStyle
        dateFormatter.timeStyle = NSDateFormatterStyle.ShortStyle
        
        var strDate = dateFormatter.stringFromDate(date.date)
       let data = strDate.componentsSeparatedByString(",")
        let data1=(data[0] as String).componentsSeparatedByString("/")
        
        println( (data1[0] as String));
    
        
        var endpoint = NSURL(string: "http://theinspirer.in/ilpscheduleapp/schedulelist_json.php?date=20"+(data1[2] as String)+"-"+(data1[0] as String)+"-"+(data1[1] as String)+"&batch="+batch.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet()).stringByReplacingOccurrencesOfString(" ", withString:""))
        
        
        GetbatchandtimeViewController.course=batch.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet()).stringByReplacingOccurrencesOfString(" ", withString:"")
        
      
        
        var temp:String?=("20"+(data1[2] as String)+"-"+(data1[0] as String)+"-"+(data1[1] as String)) as String;
        SchedulelistTableViewController.date1=temp;
        SchedulelistTableViewController.url=endpoint
     dispatch_async(dispatch_get_main_queue(), {self.performSegueWithIdentifier("manual", sender: self) })
        
    }
static    var course=""
    var data1:NSData?
    @IBOutlet weak var getschedule: UIButton!
    @IBOutlet weak var getschedulehidden: UIButton!
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
       
        
      
        
      //  let detailViewController = ((segue.destinationViewController) as! SchedulelistTableViewController)
        
       // detailViewController.data1=data1
        SchedulelistTableViewController.data1=data1;
       
        
        
        
    }
    @IBAction func hiddenbutton(sender: AnyObject) {
        
        

  

    }

    
    
    @IBAction func goback(sender: AnyObject) {
        dismissViewControllerAnimated(true, completion: nil)
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    func textFieldShouldReturn(textField: UITextField!) -> Bool // called when 'return' key pressed. return NO to ignore.
    {
        textField.resignFirstResponder()
        return true;
    }
}
