//
//  feedbackViewController.swift
//  MY-ILP
//
//  Created by lokesh deshmukh on 26/06/1937 SAKA.
//  Copyright (c) 1937 SAKA TCS. All rights reserved.
//

import UIKit

class feedbackViewController: UIViewController,UITextViewDelegate {

    
    @IBOutlet weak var comments: UITextView!
    @IBOutlet var view1: UIView!
    
    @IBOutlet weak var courseui: UITextField!
    @IBOutlet weak var nameui: UITextField!
    var rating:Int!
    var empid:String=ViewController.emp_id as String
        var empname:String=ViewController.emp_name
    var emploc:String=ViewController.emp_location
        var empbatch:String=ViewController.emp_lg
        var empslot:String=""
    
   static var name:String!
  
  static  var course:String!
    static var slot:String!
    static var errormsg=0;
    @IBAction func submit(sender: AnyObject) {
        
        
        
        if temp == 1
        {
            
            let alertController = UIAlertController(title: "Message", message:
                "Cannot Comment For Future Courses", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        
        if count(comments.text) < 1
        {
         
            let alertController = UIAlertController(title: "Message", message:
                "Please Enter Comment Before Submitting", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
                    self.presentViewController(alertController, animated: true, completion: nil)
        }
        else
        {
        println("add pressed")
        empslot=feedbackViewController.slot
        //--------------------------------loading code started
        var blurEffect = UIBlurEffect(style: UIBlurEffectStyle.Dark)
        var blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = view.bounds
        view.addSubview(blurEffectView)
        
        
        //screen shot and blur
        let snapShot = self.view.snapshotViewAfterScreenUpdates(false)
        view.addSubview(snapShot)
        UIView.animateWithDuration(0.25, animations: {
            snapShot.alpha = 0.0
            }, completion: { (finished: Bool) -> Void in
                snapShot.removeFromSuperview()
        } )
        //screen shot blur
        // Vibrancy Effect
        var vibrancyEffect = UIVibrancyEffect(forBlurEffect: blurEffect)
        var vibrancyEffectView = UIVisualEffectView(effect: vibrancyEffect)
        vibrancyEffectView.frame = view.bounds
        
        // Label for vibrant text
        var activityIndicator = UIActivityIndicatorView()
        activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.White)
        activityIndicator.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
        activityIndicator.startAnimating()
        activityIndicator.center = view.center
        
        // Add label to the vibrancy view
        vibrancyEffectView.contentView.addSubview(activityIndicator)
        
        // Add the vibrancy view to the blur view
        blurEffectView.contentView.addSubview(vibrancyEffectView)
        //------------------------------------------loading code end
        
        
        var uurl:String="http://theinspirer.in/ilpscheduleapp/feedback_json.php?faculty="+nameui.text+"&course="+courseui.text+"&comment="+comments.text+"&rate="+String(rate)+"&empid="+empid+"&empname="+empname+"&emploc="+emploc+"&empbatch="+empbatch+"&slot="+empslot+"&date="+printTimestamp();
        
        var endpoint = NSURL(string: uurl.stringByReplacingOccurrencesOfString(" ", withString: "%20", options: NSStringCompareOptions.LiteralSearch, range: nil) )
        var url = endpoint
        var request = NSURLRequest(URL: url!)// Creating Http Request
        
        // Creating NSOperationQueue to which the handler block is dispatched when the request completes or failed
        var queue: NSOperationQueue = NSOperationQueue()
        
        // Sending Asynchronous request using NSURLConnection
        NSURLConnection.sendAsynchronousRequest(request, queue: queue, completionHandler:{(response:NSURLResponse!, responseData:NSData!, error: NSError!) ->Void in
            
            if error != nil
            {
                   dispatch_async(dispatch_get_main_queue()) {
                println(error.description)
                blurEffectView.removeFromSuperview();
                let alertController = UIAlertController(title: "Message", message:
                    "Network Error", preferredStyle: UIAlertControllerStyle.Alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
                
                self.presentViewController(alertController, animated: true, completion: nil)
                }
            }
            else
            {
                   dispatch_async(dispatch_get_main_queue()) {
                                blurEffectView.removeFromSuperview();
                //Converting data to String
                var responseStr:NSString = NSString(data:responseData, encoding:NSUTF8StringEncoding)!
                //  self.hiddenbutton.sendActionsForControlEvents(UIControlEvents.TouchUpInside)
                
                println(responseStr)
                //  blurEffectView.removeFromSuperview();
                if responseStr.containsString("success")
                {
                    let alertController = UIAlertController(title: "Message", message:
                        "Posted Sucessfully", preferredStyle: UIAlertControllerStyle.Alert)
                    alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
                    
                    self.presentViewController(alertController, animated: true, completion: nil)
                }
                    if responseStr.containsString("already")
                    {
                        let alertController = UIAlertController(title: "Message", message:
                            "You Have Already Given Feedback For This Session", preferredStyle: UIAlertControllerStyle.Alert)
                        alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
                        
                        self.presentViewController(alertController, animated: true, completion: nil)
                    }
                }
                
                
            }
        })
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        rate=1;
        comments.delegate=self
        
       
        
        self.view1.backgroundColor = UIColor(patternImage: UIImage(named: "background.jpg")!)
        //var homeButton : UIBarButtonItem = UIBarButtonItem(title: "LeftButtonTitle", style: UIBarButtonItemStyle.Plain, target: self, action: "")
        
       // var logButton : UIBarButtonItem = UIBarButtonItem(title: "Submit", style: UIBarButtonItemStyle.Plain, target: self, action: "addTapped:")
        
       // self.navigationItem.leftBarButtonItem = homeButton
     //   self.navigationItem.rightBarButtonItem = logButton
        // Do any additional setup after loading the view.
        nameui.text=feedbackViewController.name
        courseui.text=feedbackViewController.course
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }
    func printTimestamp()-> String {
        
        var todaysDate:NSDate = NSDate()
        var dateFormatter:NSDateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        var todayString:String = dateFormatter.stringFromDate(todaysDate)
        
        println(todayString)
        return todayString
        
    }
    @IBAction func submitfeedback(sender: AnyObject) {
        
      /*  var uurl:String="http://theinspirer.in/ilpscheduleapp/feedback_json.php?faculty="+nameui.text+"&course="+courseui.text+"&comment="+comments.text+"&rate="+String(rate)+"&empid="+empid+"&empname="+empname+"&emploc="+emploc+"&empbatch="+empbatch+"&slot="+empslot+"&date="+printTimestamp();
        
        var endpoint = NSURL(string: uurl )
        var url = endpoint
        var request = NSURLRequest(URL: url!)// Creating Http Request
        
        // Creating NSOperationQueue to which the handler block is dispatched when the request completes or failed
        var queue: NSOperationQueue = NSOperationQueue()
        
        // Sending Asynchronous request using NSURLConnection
        NSURLConnection.sendAsynchronousRequest(request, queue: queue, completionHandler:{(response:NSURLResponse!, responseData:NSData!, error: NSError!) ->Void in
            
            if error != nil
            {
                println(error.description)
                
            }
            else
            {
                //Converting data to String
                var responseStr:NSString = NSString(data:responseData, encoding:NSUTF8StringEncoding)!
                //  self.hiddenbutton.sendActionsForControlEvents(UIControlEvents.TouchUpInside)
                
                println(responseStr)
                //  blurEffectView.removeFromSuperview();
                
                
                
                
            }
        })*/
        //feedback code
    }
    var rate:Int32!
    
    @IBOutlet weak var star5: UIButton!
    @IBOutlet weak var star4: UIButton!
    @IBOutlet weak var star3: UIButton!
    @IBOutlet weak var star2: UIButton!
    @IBOutlet weak var star1: UIButton!
    
 
    
    @IBAction func star1(sender: AnyObject) {
        
       
       let image = UIImage(named: "starfilled.png") as UIImage!
        
        star1.setImage(image, forState: UIControlState.Normal)
        
            
            
            let image1 = UIImage(named: "starempty.png") as UIImage!
            star2.setImage(image1, forState: UIControlState.Normal)
            star3.setImage(image1, forState: UIControlState.Normal)
            star4.setImage(image1, forState: UIControlState.Normal)
            star5.setImage(image1, forState: UIControlState.Normal)

      
                    rate=1;
        
        
      
    }
  
    @IBAction func star2(sender: AnyObject) {
        
            let image = UIImage(named: "starfilled.png") as UIImage!
            
            star2.setImage(image, forState: UIControlState.Normal)
            star1.setImage(image, forState: UIControlState.Normal)
            
            
            
            let image1 = UIImage(named: "starempty.png") as UIImage!
            star3.setImage(image1, forState: UIControlState.Normal)
            star4.setImage(image1, forState: UIControlState.Normal)
            star5.setImage(image1, forState: UIControlState.Normal)
            
        
            rate=2;
            
            
       
    }
    @IBAction func star3(sender: AnyObject) {
        let image = UIImage(named: "starfilled.png") as UIImage!
        
        star2.setImage(image, forState: UIControlState.Normal)
        star1.setImage(image, forState: UIControlState.Normal)
        star3.setImage(image, forState: UIControlState.Normal)
        
        
        let image1 = UIImage(named: "starempty.png") as UIImage!
        
        star4.setImage(image1, forState: UIControlState.Normal)
        star5.setImage(image1, forState: UIControlState.Normal)
        
    
        rate=3;
    }
    
    @IBAction func star4(sender: AnyObject) {
        let image = UIImage(named: "starfilled.png") as UIImage!
        
        star2.setImage(image, forState: UIControlState.Normal)
        star1.setImage(image, forState: UIControlState.Normal)
        star3.setImage(image, forState: UIControlState.Normal)
        star4.setImage(image, forState: UIControlState.Normal)
        
        
        let image1 = UIImage(named: "starempty.png") as UIImage!
        
       
        star5.setImage(image1, forState: UIControlState.Normal)
        
        rate=4;
    }
    
    @IBAction func star5(sender: AnyObject) {
        let image = UIImage(named: "starfilled.png") as UIImage!
        
        star2.setImage(image, forState: UIControlState.Normal)
        star1.setImage(image, forState: UIControlState.Normal)
        star3.setImage(image, forState: UIControlState.Normal)
        star4.setImage(image, forState: UIControlState.Normal)
        
        star5.setImage(image, forState: UIControlState.Normal)
        
        
    }
    override func viewWillAppear(animated: Bool) {
        navigationItem.title = "Feedback"
     disable()
       
    }
        var temp=0
    func disable()
    {
        //disable ui for future dates
        var todaysDate:NSDate = NSDate()
        var dateFormatter:NSDateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        var todayString:String = dateFormatter.stringFromDate(todaysDate)
        
        
        var dateFormatter1 = NSDateFormatter()
        
        
        let datatoday = todayString.componentsSeparatedByString("-")
        let data = SchedulelistTableViewController.date1!.componentsSeparatedByString("-")
        
    
        if datatoday[0].toInt() >= data[0].toInt()
        {
            if datatoday[1].toInt() >= data[1].toInt()
            {
                
                if datatoday[2].toInt() >= data[2].toInt()
                {
                    temp = 0
                }
                else
                {
                   temp=1
                   // self.dismissViewControllerAnimated(false, completion: nil);
                }
                
            }
            else
            {
                temp=1
             //   self.dismissViewControllerAnimated(false, completion: nil);
            }
        }
        else
        {
            temp=1
           // self.dismissViewControllerAnimated(false, completion: nil);
        }
       
        //disable ui for future dates
    }
    /*
   
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        return true
    }

}
