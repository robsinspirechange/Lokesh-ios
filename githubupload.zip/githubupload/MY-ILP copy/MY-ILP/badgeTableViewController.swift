//
//  badgeTableViewController.swift
//  MY-ILP
//
//  Created by lokesh deshmukh on 26/06/1937 SAKA.
//  Copyright (c) 1937 SAKA TCS. All rights reserved.
//

import UIKit

class badgeTableViewController: UITableViewController {
    
   
    
    @IBOutlet weak var view1: UIView!
    @IBOutlet var tableview: UITableView!
    @IBAction func goback(sender: AnyObject) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    @IBOutlet weak var badgename: UILabel!
    
    @IBOutlet weak var badgeimage: UIImageView!
    @IBOutlet weak var badge_quote: UILabel!
    @IBOutlet weak var mypoints: UILabel!
    var badgelistarchitecturevar = [badgelistarchitecture]()
    override func viewDidLoad() {
        super.viewDidLoad()
          //   self.mypoints.text="asd";
        if UIScreen.mainScreen().bounds.size.height>768
        {
            uitable?.rowHeight=100;
        }
        self.view1.backgroundColor = UIColor(patternImage: UIImage(named: "background.jpg")!)
        loadSampleMeals()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    static var errormsg=0;
    func loadSampleMeals() {
        
        
        //--------------------------------loading code started
        var blurEffect = UIBlurEffect(style: UIBlurEffectStyle.Dark)
        var blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = view.bounds
        tableview.addSubview(blurEffectView)
        
        
        //screen shot and blur
        let snapShot = self.view.snapshotViewAfterScreenUpdates(false)
        view.addSubview(snapShot)
        UIView.animateWithDuration(0.25, animations: {
            snapShot.alpha = 0.0
            }, completion: { (finished: Bool) -> Void in
                snapShot.removeFromSuperview()
        } )
        //screen shot blur
        // Vibrancy Effect
        var vibrancyEffect = UIVibrancyEffect(forBlurEffect: blurEffect)
        var vibrancyEffectView = UIVisualEffectView(effect: vibrancyEffect)
        vibrancyEffectView.frame = view.bounds
        
        // Label for vibrant text
        var activityIndicator = UIActivityIndicatorView()
        activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.White)
        activityIndicator.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
        activityIndicator.startAnimating()
        activityIndicator.center = view.center
        
        // Add label to the vibrancy view
        vibrancyEffectView.contentView.addSubview(activityIndicator)
        
        // Add the vibrancy view to the blur view
        blurEffectView.contentView.addSubview(vibrancyEffectView)
        //------------------------------------------loading code end
        
        
        badgeTableViewController.errormsg=0;
        var endpoint = NSURL(string: "http://theinspirer.in/ilpscheduleapp/leaderboard_iD351r3_json.php?empid="+ViewController.emp_id+"&batch="+ViewController.emp_lg)
        var url = endpoint
        var request = NSURLRequest(URL: url!)// Creating Http Request
        
        // Creating NSOperationQueue to which the handler block is dispatched when the request completes or failed
        var queue: NSOperationQueue = NSOperationQueue()
        
        // Sending Asynchronous request using NSURLConnection
        NSURLConnection.sendAsynchronousRequest(request, queue: queue, completionHandler:{(response:NSURLResponse!, responseData:NSData!, error: NSError!) ->Void in
            
            if error != nil
            {
                println(error.description)
      
                dispatch_async(dispatch_get_main_queue()) {
                    //blurEffectView.removeFromSuperview();
                 badgeTableViewController.errormsg=1;
                    self.dismissViewControllerAnimated(false, completion: nil);
                }
            }
            else
            {
                  dispatch_async(dispatch_get_main_queue()) {
                 var data1:NSData!
                //Converting data to String
                var responseStr:NSString = NSString(data:responseData, encoding:NSUTF8StringEncoding)!
                data1=responseStr.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                    blurEffectView.hidden=true;
                self.view.backgroundColor = UIColor.whiteColor()
                
                if let json: NSDictionary = NSJSONSerialization.JSONObjectWithData(data1!, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary {
                    
                     let items = json
                    var temp: NSDictionary=items as NSDictionary
                    for (key, value) in temp {
                        if !(value is NSNull)
                        {
                            if(key as! String)=="MyPoints"
                            {
                                var temp:String=value as! String
                                    self.mypoints.text=temp
                                var pointint:Int?=temp.toInt()
                                
                                if pointint>=0 && pointint<=15
                                {
                                    self.badge_quote.text="You need to have "+String(15-pointint!)+" more points to win Karma Warrior Badge"
                                    self.badgename.text="Default Badge"
                                    self.badgeimage.image = UIImage(named: "badge5.png")!
                                }
                                else if pointint>15 && pointint<=30
                                {
                                    self.badge_quote.text="You need to have "+String(30-pointint!)+" more points to win Karma Emp Power"
                                    self.badgename.text="Karma Warrior Badge"
                                     self.badgeimage.image = UIImage(named: "badge1.png")!
                                }
                                else if pointint>30 && pointint<=60
                                {
                                    self.badge_quote.text="You need to have "+String(60-pointint!)+" more points to win Karma Leader"
                                    self.badgename.text="Karma Emp Badge"
                                     self.badgeimage.image = UIImage(named: "badge2.png")!
                                }
                                else if pointint>60 && pointint<=100
                                {
                                    self.badge_quote.text="You need to have "+String(100-pointint!)+" more points to win Karma King"
                                    self.badgename.text="Karma Leader"
                                     self.badgeimage.image = UIImage(named: "badge3.png")!
                                }
                                else if pointint>100
                                {
                                     self.badge_quote.text="Congratualtion You Have the Heigest Badge"
                                    self.badgename.text="Karma Leader"
                                     self.badgeimage.image = UIImage(named: "badge4.png")!
                                }
                                
                                
                                
                                
                                break
                            }
                           
                        }
                        
                    }
                    
                    
                    
                    
                        
                    

                    
                    if let items = json["Android"] as? NSArray {
                        for item in items {
                            
                    
                            
                            var name:String=""
                            var points:String=""
                            
                            
                   
                            var temp: NSDictionary=item as! NSDictionary
                            for (key, value) in temp {
                                if !(value is NSNull)
                                {
                                    if(key as! String)=="emp_name"
                                    {
                                        name=value as! String
                                    }
                                    if(key as! String)=="points"
                                    {
                                        points=value as! String
                                    }
                                    
                                }
                                
                            }
                            
                            println(name)
                            
                            let   ScheduleArchitecture4 = badgelistarchitecture(name: name as String,points :points)!
                            self.badgelistarchitecturevar += [ScheduleArchitecture4]
                      
                            
                            //println(item);
                            // construct your model objects here
                        }
                    }
                    }
                self.uitable.reloadData()
                }
                

                
            }
        })
        
      
        
              //network load
        
        
        //network load
        
        
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete method implementation.
        // Return the number of rows in the section.
        return badgelistarchitecturevar.count
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cellIdentifier = "badgeTableViewCell"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as! badgeTableViewCell
        
        // Fetches the appropriate meal for the data source layout.
        let obj = badgelistarchitecturevar[indexPath.row]
        
        cell.name.text = obj.name
        cell.points.text=obj.points

        // cell.course.text = obj.
        
        //network loader
        /*  ImageLoader.sharedLoader.imageForUrl("http://cdn2.raywenderlich.com/wp-content/themes/raywenderlich/images/store/profile-page-products/i6t@2x.png", completionHandler:{(image: UIImage?, url: String) in
        cell.image1.image = image!
        })*/
        //network loader
        
        
        return cell
    }
    
    
    func getDataFromUrl(urL:NSURL, completion: ((data: NSData?) -> Void)) {
        NSURLSession.sharedSession().dataTaskWithURL(urL) { (data, response, error) in
            completion(data: data)
            }.resume()
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        //CODE TO BE RUN ON CELL TOUCH
        println(indexPath.item);
        
        //   let vc = storyboard!.instantiateViewControllerWithIdentifier("Schedule") as! UIViewController
        // self.presentViewController(vc, animated: true, completion: nil)
        
        
    }
    
   
    @IBOutlet var uitable: UITableView!
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        
        
        
        
        
        
    }
    override func viewWillAppear(animated: Bool) {
        navigationItem.title = "Contacts"
        
    }
    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
    // Return NO if you do not want the specified item to be editable.
    return true
    }
    */
    
    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
    if editingStyle == .Delete {
    // Delete the row from the data source
    tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
    } else if editingStyle == .Insert {
    // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }
    }
    */
    
    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
    
    }
    */
    
    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
    // Return NO if you do not want the item to be re-orderable.
    return true
    }
    */
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    }
    */
    

class ImageLoader {
    
    var cache = NSCache()
    
    class var sharedLoader : ImageLoader {
        struct Static {
            static let instance : ImageLoader = ImageLoader()
        }
        return Static.instance
    }
    
    func imageForUrl(urlString: String, completionHandler:(image: UIImage?, url: String) -> ()) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), {()in
            var data: NSData? = self.cache.objectForKey(urlString) as? NSData
            
            if let goodData = data {
                let image = UIImage(data: goodData)
                dispatch_async(dispatch_get_main_queue(), {() in
                    completionHandler(image: image, url: urlString)
                })
                return
            }
            
            var downloadTask: NSURLSessionDataTask = NSURLSession.sharedSession().dataTaskWithURL(NSURL(string: urlString)!, completionHandler: {(data: NSData!, response: NSURLResponse!, error: NSError!) -> Void in
                if (error != nil) {
                    completionHandler(image: nil, url: urlString)
                    return
                }
                
                if data != nil {
                    let image = UIImage(data: data)
                    self.cache.setObject(data, forKey: urlString)
                    dispatch_async(dispatch_get_main_queue(), {() in
                        completionHandler(image: image, url: urlString)
                    })
                    return
                }
                
            })
            downloadTask.resume()
        })
        
    }

}
}
