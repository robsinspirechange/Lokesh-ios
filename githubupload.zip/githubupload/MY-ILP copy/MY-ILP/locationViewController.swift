//
//  locationViewController.swift
//  MY-ILP
//
//  Created by lokesh deshmukh on 21/07/1937 SAKA.
//  Copyright (c) 1937 SAKA TCS. All rights reserved.
//

import UIKit

class locationViewController: UIViewController {

    @IBAction func Ahemdabad(sender: AnyObject) {
        ViewController.location="Ahemdabad"
        self.dismissViewControllerAnimated(true, completion: nil);
        
    }
    @IBAction func Hyderabad(sender: AnyObject) {
        ViewController.location="Hyderabad"
        self.dismissViewControllerAnimated(true, completion: nil);
    }
    @IBAction func guhati(sender: AnyObject) {
        ViewController.location="Chennai"
        self.dismissViewControllerAnimated(true, completion: nil);
    }
    
    @IBAction func trivandrum(sender: AnyObject) {
                ViewController.location="Trivandrum"
        self.dismissViewControllerAnimated(true, completion: nil);
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(animated: Bool) {
        navigationItem.title = "Location"
        
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
