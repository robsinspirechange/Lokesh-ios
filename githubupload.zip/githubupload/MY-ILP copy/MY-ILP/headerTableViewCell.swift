//
//  headerTableViewCell.swift
//  MY-ILP
//
//  Created by lokesh deshmukh on 09/07/1937 SAKA.
//  Copyright (c) 1937 SAKA TCS. All rights reserved.
//

import UIKit

class headerTableViewCell: UITableViewCell {
    @IBOutlet weak var header: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
