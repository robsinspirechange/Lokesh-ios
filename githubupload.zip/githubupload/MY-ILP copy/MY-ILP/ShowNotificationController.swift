//
//  ShowNotificationController.swift
//  MY-ILP
//
//  Created by lokesh deshmukh on 25/06/1937 SAKA.
//  Copyright (c) 1937 SAKA TCS. All rights reserved.
//

import UIKit

class ShowNotificationController: UIViewController {

    static var errormsg=0;
    @IBOutlet weak var Label1: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        //--------------------------------loading code started
        var blurEffect = UIBlurEffect(style: UIBlurEffectStyle.Dark)
        var blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = view.bounds
        view.addSubview(blurEffectView)
        
        
        //screen shot and blur
        let snapShot = self.view.snapshotViewAfterScreenUpdates(false)
        view.addSubview(snapShot)
        UIView.animateWithDuration(0.25, animations: {
            snapShot.alpha = 0.0
            }, completion: { (finished: Bool) -> Void in
                snapShot.removeFromSuperview()
        } )
        //screen shot blur
        // Vibrancy Effect
        var vibrancyEffect = UIVibrancyEffect(forBlurEffect: blurEffect)
        var vibrancyEffectView = UIVisualEffectView(effect: vibrancyEffect)
        vibrancyEffectView.frame = view.bounds
        
        // Label for vibrant text
        var activityIndicator = UIActivityIndicatorView()
        activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.White)
        activityIndicator.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
        activityIndicator.startAnimating()
        activityIndicator.center = view.center
        
        // Add label to the vibrancy view
        vibrancyEffectView.contentView.addSubview(activityIndicator)
        
        // Add the vibrancy view to the blur view
        blurEffectView.contentView.addSubview(vibrancyEffectView)
        //------------------------------------------loading code end
        
        ShowNotificationController.errormsg=0;
          var uurl:String="http://theinspirer.in/ilpscheduleapp/notify_json.php";
        
        var endpoint = NSURL(string: uurl )
        var url = endpoint
        var request = NSURLRequest(URL: url!)// Creating Http Request
        
        // Creating NSOperationQueue to which the handler block is dispatched when the request completes or failed
        var queue: NSOperationQueue = NSOperationQueue()
        
        // Sending Asynchronous request using NSURLConnection
        NSURLConnection.sendAsynchronousRequest(request, queue: queue, completionHandler:{(response:NSURLResponse!, responseData:NSData!, error: NSError!) ->Void in
        
        if error != nil
        {
        println(error.description)
         dispatch_async(dispatch_get_main_queue()) {
         ShowNotificationController.errormsg=1;
            self.dismissViewControllerAnimated(false, completion: nil);
            }
        }
        else
        {
            dispatch_async(dispatch_get_main_queue()) {
            blurEffectView.hidden=true;
        //Converting data to String
        var responseStr:NSString = NSString(data:responseData, encoding:NSUTF8StringEncoding)!
        //  self.hiddenbutton.sendActionsForControlEvents(UIControlEvents.TouchUpInside)
            if let json: NSDictionary = NSJSONSerialization.JSONObjectWithData(responseStr.dataUsingEncoding(NSUTF8StringEncoding)!, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary {
                if let items = json["Android"] as? NSArray {
                    for item in items {
                        
                        var temp: NSDictionary=item as! NSDictionary
                        for (key, value) in temp {
                            if !(value is NSNull)
                            {
                                if(key as! String)=="message"
                                {
                                    
                                    
                                        self.Label1.text=value as? String;
                                        
                                    
                                }
                                
                            }
                            
                        }
                        
                        
                        
                        //println(item);
                        // construct your model objects here
                    }
                }
            }
            

        println(responseStr)
        //  blurEffectView.removeFromSuperview();
            }
        
        
        }
        })
     
       
       /*
        var endpoint = NSURL(string: "http://theinspirer.in/ilpscheduleapp/notify_json.php")
        var data1 = NSData(contentsOfURL: endpoint!)
        
        if let json: NSDictionary = NSJSONSerialization.JSONObjectWithData(data1!, options: NSJSONReadingOptions.MutableContainers, error: nil) as? NSDictionary {
            if let items = json["Android"] as? NSArray {
                for item in items {
                   
                    var temp: NSDictionary=item as! NSDictionary
                    for (key, value) in temp {
                        if !(value is NSNull)
                        {
                            if(key as! String)=="message"
                            {
                                  Label1.text=value as? String;
                            }
                           
                        }
                        
                    }
                    
                    
                    
                    //println(item);
                    // construct your model objects here
                }
            }
        }
*/
        
      
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    @IBOutlet weak var menuitem: UIBarButtonItem!
    @IBAction func dismissNav(sender: AnyObject) {
        dismissViewControllerAnimated(true, completion: nil)
    }
}
