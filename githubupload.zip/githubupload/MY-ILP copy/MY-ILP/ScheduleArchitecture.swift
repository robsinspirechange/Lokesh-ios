//
//  ScheduleArchitecture.swift
//  MY-ILP
//
//  Created by lokesh deshmukh on 26/06/1937 SAKA.
//  Copyright (c) 1937 SAKA TCS. All rights reserved.
//
import UIKit

class ScheduleArchitecture {
    // MARK: Properties
    
    var slot: String
    var course: String
    var faculty: String
    var room: String
    

    
    
    // MARK: Initialization
    
    init?(slot: String,course: String,faculty: String,room: String) {
        // Initialize stored properties.
        self.slot = slot
        self.course = course
        self.faculty = faculty
        self.room = room
        
        
        // Initialization should fail if there is no name or if the rating is negative.
        
    }
    
}