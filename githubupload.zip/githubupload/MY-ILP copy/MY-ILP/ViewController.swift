//
//  ViewController.swift
//  MY-ILP
//
//  Created by lokesh deshmukh on 25/06/1937 SAKA.
//  Copyright (c) 1937 SAKA TCS. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITextFieldDelegate {

    @IBOutlet var view1: UIView!
    @IBOutlet weak var scrollview: UIScrollView!
    @IBOutlet weak var Employee_Emailid: UITextField!
    @IBOutlet weak var Employee_Location: UITextField!
    @IBOutlet weak var employee_lg: UITextField!
    @IBOutlet weak var Employee_name: UITextField!
    @IBOutlet var Employee_id: UITextField!
    
  static  var location:String?="-Select-"
    
    @IBOutlet weak var locationbutton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
   
        
        
        // Do any additional setup after loading the view, typically from a nib.
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("keyboardWillShow:"), name:UIKeyboardWillShowNotification, object: nil);
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("keyboardWillHide:"), name:UIKeyboardWillHideNotification, object: nil);
        scrollview.contentSize = CGSizeMake(400, 850)
       //  self.view1.backgroundColor = UIColor(patternImage: UIImage(named: "background.jpg")!)
      //  self.scrollview.backgroundColor = UIColor(patternImage: UIImage(named: "background.jpg")!)
        
        let screenSize: CGRect = UIScreen.mainScreen().bounds
        let screenWidth = screenSize.width
        let screenHeight = screenSize.height
        view1.frame = CGRectMake(0 , 0, self.view.frame.width, self.view.frame.height)
        
        navigationController?.navigationBar.tintColor=UIColor.blueColor();
        navigationController?.navigationBar.backgroundColor=UIColor(patternImage: UIImage(named: "background.jpg")!);
        
     let padding = UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 5);
        //Employee_id.leftView=padding;
        // Employee_id.layer.sublayerTransform=CATransform3DMakeTranslation(5, 5, 0);
       /*
         Employee_id.layer.borderColor=(UIColor.whiteColor()).CGColor
        Employee_Location.layer.borderColor=(UIColor.whiteColor()).CGColor
        employee_lg.layer.borderColor=(UIColor.whiteColor()).CGColor
        Employee_Emailid.layer.borderColor=(UIColor.whiteColor()).CGColor
        Employee_name.layer.borderColor=(UIColor.whiteColor()).CGColor
        
        Employee_id.layer.borderWidth=1;
        Employee_Location.layer.borderWidth=1;
                employee_lg.layer.borderWidth=1;
                Employee_name.layer.borderWidth=1;
                Employee_Emailid.layer.borderWidth=1;
       if true {
        let border = CALayer()
        let width = CGFloat(2.0)
        border.borderColor = UIColor.darkGrayColor().CGColor
        border.frame = CGRect(x: 0, y: Employee_id.frame.size.height - width, width:  Employee_id.frame.size.width, height: Employee_id.frame.size.height)
        
        border.borderWidth = width
        Employee_id.layer.addSublayer(border)
        Employee_id.layer.masksToBounds = true
    
        Employee_id.delegate=self
        }
        if true
        {
        let border = CALayer()
        let width = CGFloat(2.0)
        border.borderColor = UIColor.darkGrayColor().CGColor
        border.frame = CGRect(x: 0, y: Employee_Location.frame.size.height - width, width:  Employee_Location.frame.size.width, height: Employee_Location.frame.size.height)
        
        border.borderWidth = width
        Employee_Location.layer.addSublayer(border)
        Employee_Location.layer.masksToBounds = true
        Employee_Location.delegate=self
        }
        if true
        {
        let border = CALayer()
        let width = CGFloat(2.0)
        border.borderColor = UIColor.darkGrayColor().CGColor
        border.frame = CGRect(x: 0, y: Employee_Emailid.frame.size.height - width, width:  Employee_Emailid.frame.size.width, height: Employee_Emailid.frame.size.height)
        
        border.borderWidth = width
        Employee_Emailid.layer.addSublayer(border)
        Employee_Emailid.layer.masksToBounds = true
        Employee_Emailid.delegate=self
        }
        if true
        {
            let border = CALayer()
            let width = CGFloat(2.0)
            border.borderColor = UIColor.darkGrayColor().CGColor
            border.frame = CGRect(x: 0, y: employee_lg.frame.size.height - width, width:  employee_lg.frame.size.width, height: employee_lg.frame.size.height)
            
            border.borderWidth = width
            employee_lg.layer.addSublayer(border)
            employee_lg.layer.masksToBounds = true
            employee_lg.delegate=self
        }
        if true
        {
            let border = CALayer()
            let width = CGFloat(2.0)
            border.borderColor = UIColor.darkGrayColor().CGColor
            border.frame = CGRect(x: 0, y: Employee_name.frame.size.height - width, width:  Employee_name.frame.size.width, height: Employee_name.frame.size.height)
            
            border.borderWidth = width
            Employee_name.layer.addSublayer(border)
            Employee_name.layer.masksToBounds = true
            Employee_name.delegate=self
        }*/
         self.view1.backgroundColor = UIColor(patternImage: UIImage(named: "background.jpg")!)
    }
    override func viewWillAppear(animated: Bool) {
        //navigationItem.title = "My ILP"
        locationbutton.setTitle(ViewController.location, forState: .Normal)
        let defaults = NSUserDefaults.standardUserDefaults()
      defaults.classForCoder
        
        if let stringOne = defaults.valueForKey("EMP_ID") as? String {
            
              // Another String Value
                println(stringOne) // Some String Value
        
            
            ViewController.emp_id=defaults.valueForKey("EMP_ID") as? String;
            ViewController.emp_location=defaults.valueForKey("EMP_CITY") as? String;
            ViewController.emp_lg=defaults.valueForKey("EMP_LG") as? String;
            ViewController.emp_name=defaults.valueForKey("EMP_NAME") as? String;
            ViewController.emp_email=defaults.valueForKey("EMP_EMAILID") as? String;
            
            dispatch_async(dispatch_get_main_queue(), {self.performSegueWithIdentifier("tomenu", sender: self) })
//                    performSegueWithIdentifier("tomenu", sender: self)
        }

        
        
        
    }
    func keyboardWillShow(sender: NSNotification) {
       // self.view.frame.origin.y -= 150
    }
    func keyboardWillHide(sender: NSNotification) {
        //self.view.frame.origin.y += 150
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    var blur:UIVisualEffectView?
    @IBAction func testbutton(sender: AnyObject) {
     /*   blur = UIVisualEffectView(effect: UIBlurEffect(style: UIBlurEffectStyle.Light))
        blur!.frame = view.frame
        view.addSubview(blur!)
       */ 
    }

    @IBOutlet weak var loader: UIActivityIndicatorView!

    @IBOutlet weak var hiddenbutton: UIButton!
    
    
    internal static var emp_id:String!
        internal static var emp_location:String!
        internal static var emp_lg:String!
        internal static var emp_name:String!
        internal static var emp_email:String!
    
    @IBAction func onsubmit(sender: AnyObject) {
    
        

        //validate fields
        if count(Employee_id.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())) < 1
        {
            let alertController = UIAlertController(title: "Message", message:
                "Enter Employee ID", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        
        if count(employee_lg.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())) < 1
        {
            let alertController = UIAlertController(title: "Message", message:
                "Enter LG Name", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
            return
            
        }
        
        if count(Employee_name.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())) < 1
        {
            let alertController = UIAlertController(title: "Message", message:
                "Enter Your Name", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
            return
            
        }
        
        if ViewController.location == "-Select-"
        {
            let alertController = UIAlertController(title: "Message", message:
                "Please Select City", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
            return
            
        }
        
        var temp:String?=Employee_Emailid.text
        
        Employee_Emailid.text=Employee_Emailid.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
        
        var error_msg:String
        error_msg="";
        if count(Employee_Emailid.text)>9
        {
        var substring1 = Employee_Emailid.text[advance(Employee_Emailid.text.startIndex, count(Employee_Emailid.text)-8)...advance(Employee_Emailid.text.startIndex, count(Employee_Emailid.text)-1)]
            
            if (substring1.lowercaseString as NSString).isEqualToString("@tcs.com")
            {
                
            }
            else
            {
               error_msg="Enter Offcial Email Id";
                
            }
        println(substring1);
        }
        else
        {
               error_msg="Enter Offcial Email Id";
        }
        
        if count(error_msg)>2
        {
            let alertController = UIAlertController(title: "Message", message:
                error_msg, preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
            
            return;
        }
        //validate fields
        
        
       ViewController.emp_id=Employee_id.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet());
        ViewController.emp_location=ViewController.location?.lowercaseString.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
        ViewController.emp_lg=employee_lg.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
        ViewController.emp_name=Employee_name.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
        ViewController.emp_email=Employee_Emailid.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
    
        
        //--------------------------------loading code started
        var blurEffect = UIBlurEffect(style: UIBlurEffectStyle.Dark)
        var blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = view.bounds
        view.addSubview(blurEffectView)
        
        
        //screen shot and blur
        let snapShot = self.view.snapshotViewAfterScreenUpdates(false)
        view.addSubview(snapShot)
        UIView.animateWithDuration(0.25, animations: {
            snapShot.alpha = 0.0
            }, completion: { (finished: Bool) -> Void in
                snapShot.removeFromSuperview()
        } )
        //screen shot blur
        // Vibrancy Effect
        var vibrancyEffect = UIVibrancyEffect(forBlurEffect: blurEffect)
        var vibrancyEffectView = UIVisualEffectView(effect: vibrancyEffect)
        vibrancyEffectView.frame = view.bounds
        
        // Label for vibrant text
        var activityIndicator = UIActivityIndicatorView()
        activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.White)
        activityIndicator.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
        activityIndicator.startAnimating()
        activityIndicator.center = view.center
        
        // Add label to the vibrancy view
        vibrancyEffectView.contentView.addSubview(activityIndicator)
        
        // Add the vibrancy view to the blur view
        blurEffectView.contentView.addSubview(vibrancyEffectView)
        //------------------------------------------loading code end
        
          var uurl:String="http://theinspirer.in/ilpscheduleapp/registerapple.php?id="+Employee_id.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet()).stringByReplacingOccurrencesOfString(" ", withString:"")+"&loc="+ViewController.location!.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())+"&batch="+employee_lg.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet()).stringByReplacingOccurrencesOfString(" ", withString:"")+"&name="+Employee_name.text.stringByReplacingOccurrencesOfString(" ", withString:"%20")+"&email="+Employee_Emailid.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet()).stringByReplacingOccurrencesOfString(" ", withString:"")+"&regId=&imei="+UIDevice.currentDevice().identifierForVendor.UUIDString;
        
        var endpoint = NSURL(string: uurl )
        
        var url = endpoint
        var request = NSURLRequest(URL: url!)// Creating Http Request
        
        // Creating NSOperationQueue to which the handler block is dispatched when the request completes or failed
        var queue: NSOperationQueue = NSOperationQueue()
        
        // Sending Asynchronous request using NSURLConnection
        NSURLConnection.sendAsynchronousRequest(request, queue: queue, completionHandler:{(response:NSURLResponse!, responseData:NSData!, error: NSError!) ->Void in
            
            if error != nil
            {
                println(error.description)
                dispatch_async(dispatch_get_main_queue()) {
                    blurEffectView.removeFromSuperview();
                    let alertController = UIAlertController(title: "Message", message:
                        "Network Error", preferredStyle: UIAlertControllerStyle.Alert)
                    alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
                    
                    self.presentViewController(alertController, animated: true, completion: nil)
                }
            }
            else
            {
                dispatch_async(dispatch_get_main_queue()) {
                    blurEffectView.removeFromSuperview();
                //Converting data to String
                var responseStr:NSString = NSString(data:responseData, encoding:NSUTF8StringEncoding)!
                //  self.hiddenbutton.sendActionsForControlEvents(UIControlEvents.TouchUpInside)
                
                println(responseStr)
                    let defaults = NSUserDefaults.standardUserDefaults()
                    
                    
                  
                    
                    
                    defaults.setValue(self.Employee_id.text, forKey: "EMP_ID")
                    defaults.setValue(ViewController.location?.lowercaseString, forKey: "EMP_CITY")
                    defaults.setValue(self.employee_lg.text, forKey: "EMP_LG")
                    defaults.setValue(self.Employee_name.text, forKey: "EMP_NAME")
                    defaults.setValue(self.Employee_Emailid.text, forKey: "EMP_EMAILID")
                    
                    defaults.synchronize()
                    
                    if responseStr.isEqualToString("Sucess")
                    {
                    self.performSegueWithIdentifier("tomenu", sender: self)
                    }
                    else
                    {
                        self.performSegueWithIdentifier("tomenu", sender: self)
                        
                    }
                    
                    
                //  blurEffectView.removeFromSuperview();
                    
                
                }
              
            }
        })

      
    }
    // UITextField Delegates
    func textFieldDidBeginEditing(textField: UITextField) {
       // println("TextField did begin editing method called")
    }
    func textFieldDidEndEditing(textField: UITextField) {
       // println("TextField did end editing method called")
    }
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        //println("TextField should begin editing method called")
        return true;
    }
    func textFieldShouldClear(textField: UITextField) -> Bool {
       // println("TextField should clear method called")
        return true;
    }
    func textFieldShouldEndEditing(textField: UITextField) -> Bool {
        //println("TextField should snd editing method called")
        return true;
    }
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        //println("While entering the characters this method gets called")
        return true;
    }
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        //println("TextField should return method called")
        Employee_id.resignFirstResponder();
        return true;
    }
    
    
    
    
    
}

