//
//  emergencyarchitecture.swift
//  MY-ILP
//
//  Created by lokesh deshmukh on 27/06/1937 SAKA.
//  Copyright (c) 1937 SAKA TCS. All rights reserved.
//

import UIKit

class emergencyarchitecture {
    // MARK: Properties
    
    var title: String?
    var number: String?
   
    
    
    
    
    // MARK: Initialization
    
    init?(title: String,number: String) {
        // Initialize stored properties.
        self.title = title
        self.number = number
        
        
        // Initialization should fail if there is no name or if the rating is negative.
        
    }
    
}